package com.example.ibm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.service.security.IamOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImages;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;

public class MainActivity extends Activity {
    ImageView viewImage;
    TextView resulttext;
    Button b;
    String api_key;
    VisualRecognition mVisualRecognition;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mVisualRecognition = new VisualRecognition("2018-03-19");
        mVisualRecognition.setApiKey(api_key = "BtO5_BhlUNAvqCK_AcY3v6r6U3LoH2c5MRk95FdFkaDk");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.btnSelectPhoto);
        resulttext = findViewById(R.id.resultview);
        viewImage=findViewById(R.id.viewImage);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds options to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    // Create the camera_intent ACTION_IMAGE_CAPTURE
                    // it will open the camera for capture the image
                    Intent camera_intent
                            = new Intent(MediaStore
                            .ACTION_IMAGE_CAPTURE);

                    // Start the activity with camera_intent,
                    // and request pic id
                    startActivityForResult(camera_intent, 1);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                // BitMap is data structure of image file
                // which store the image in memory
                Bitmap photo = (Bitmap)data.getExtras()
                        .get("data");

                // Set the image in imageview for display
                viewImage.setImageBitmap(photo);


    } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                final String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                //Log.w("path of image from gallery......******************.........", picturePath+"");
                viewImage.setImageBitmap(thumbnail);

                //IamOptions options = new IamOptions.Builder()
                  //      .apiKey("BtO5_BhlUNAvqCK_AcY3v6r6U3LoH2c5MRk95FdFkaDk")
                    //    .build();

                /*VisualRecognition service = new VisualRecognition("2018-03-19");
                service.setApiKey("BtO5_BhlUNAvqCK_AcY3v6r6U3LoH2c5MRk95FdFkaDk");

                InputStream imagesStream = null;
                try {
                    imagesStream = new FileInputStream(picturePath);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                ClassifyOptions classifyOptions = new ClassifyOptions.Builder()
                        .imagesFile(imagesStream)
                        .imagesFilename(picturePath)
                        .threshold((float) 0.6)
                        .classifierIds(Arrays.asList("DefaultCustomModel_1653902620"))
                        .build();

                ClassifiedImages result = service.classify(classifyOptions).execute();
                Gson gson = new Gson();
                String json = gson.toJson(result);
                String name = null;
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    JSONArray jsonArray = jsonObject.getJSONArray("images");
                    JSONObject jsonObject1 = jsonArray.getJSONObject(0);
                    JSONArray jsonArray1 = jsonObject1.getJSONArray("classifiers");
                    JSONObject jsonObject2 = jsonArray1.getJSONObject(0);
                    JSONArray jsonArray2 = jsonObject2.getJSONArray("classes");
                    JSONObject jsonObject3 = jsonArray2.getJSONObject(0);
                    name = jsonObject3.getString("class");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                final String finalName = name;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        TextView detectedObjects = findViewById(R.id.resultview);
                        detectedObjects.setText(finalName);
                    }
                });*/
            }
        }
    }
}
